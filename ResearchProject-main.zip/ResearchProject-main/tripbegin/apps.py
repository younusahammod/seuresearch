from django.apps import AppConfig


class TripBeginConfig(AppConfig):
    name = 'tripbegin'
