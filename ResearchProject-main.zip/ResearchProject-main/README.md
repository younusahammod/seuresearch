# TripBegin
Trip Begin OTA  Django website using [Materialize CSS framework](http://materializecss.com/).  

The database was MySQL.
